//
//  FifthViewController.swift
//  ScheurApp
//
//  Created by daan kats on 7/15/20.
//  Copyright © 2020 ViaDev. All rights reserved.
//

import UIKit

class FifthViewController: UIViewController {
    @IBOutlet weak var scheurtext: UILabel!
    
    @IBOutlet weak var totlocatie: UITextField!
    
    var heletext = ""
    var totlocatieText = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scheurtext.text = heletext
        
    }
    @IBAction func totlocatiebutton(_ sender: Any) {
        self.totlocatieText = totlocatie.text!
        performSegue(withIdentifier: "totaan", sender: self)
    }
    
    @IBAction func totplafondbutton(_ sender: Any) {
        self.totlocatieText = "de onderzijde van het plafond."
        performSegue(withIdentifier: "totaan", sender: self)
    }
    @IBAction func totvloerbutton(_ sender: Any) {
        self.totlocatieText = "de vloer"
        performSegue(withIdentifier: "totaan", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var vc = segue.destination as! SixViewController
        vc.heletext = "\(self.heletext) \(self.totlocatieText)"
    }
  

}
