//
//  FourthViewController.swift
//  ScheurApp
//
//  Created by daan kats on 7/15/20.
//  Copyright © 2020 ViaDev. All rights reserved.
//

import UIKit

class FourthViewController: UIViewController {
    @IBOutlet weak var richtinglabel: UILabel!
    
    @IBOutlet weak var wandvanaf: UITextField!
    @IBOutlet weak var plafondvanaf: UITextField!
    @IBOutlet weak var vloervanaf: UITextField!
    
    var scheurtext = ""
    var locatietext = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        richtinglabel.text = scheurtext
    }
    // volgende buttons
    @IBAction func wandlocatiebutton(_ sender: Any) {
        self.locatietext = "in de wand vanaf \(wandvanaf.text!) tot"
        performSegue(withIdentifier: "vanaf", sender: self)
    }
    @IBAction func plafondlocatiebutton(_ sender: Any) {
        self.locatietext = "in het plafond vanaf \(plafondvanaf.text!) tot"
        performSegue(withIdentifier: "vanaf", sender: self)
    }
    @IBAction func vloerlocatiebutton(_ sender: Any) {
        self.locatietext = "in de vloer vanaf \(vloervanaf.text!) tot"
        performSegue(withIdentifier: "vanaf", sender: self)
    }
    // wand buttons
    @IBAction func wanddeurkozijnbutton(_ sender: Any) {
        self.locatietext = "in de wand vanaf de bovenzijde van het deurkozijn richting"
        performSegue(withIdentifier: "vanaf", sender: self)
    }
    @IBAction func wandplafondbutton(_ sender: Any) {
        self.locatietext = "in de wand vanaf het plafond richting"
        performSegue(withIdentifier: "vanaf", sender: self)
    }
    // plafond buttons
    @IBAction func plafonddeurkozijnbutton(_ sender: Any) {
        self.locatietext = "in het plafond vanaf de bovenzijde van het deurkozijn richting"
        performSegue(withIdentifier: "vanaf", sender: self)
    }
    @IBAction func plafondplafondbutton(_ sender: Any) {
        self.locatietext = "in het plafond vanaf het plafond richting"
        performSegue(withIdentifier: "vanaf", sender: self)
    }
    // vloer buttons
    @IBAction func vloerdeurkozijnbutton(_ sender: Any) {
        self.locatietext = "in de vloer vanaf de bovenzijde van het deurkozijn richting"
        performSegue(withIdentifier: "vanaf", sender: self)
    }
    @IBAction func vloerplafondbutton(_ sender: Any) {
        self.locatietext = "in de vloer vanaf het plafond richting"
        performSegue(withIdentifier: "vanaf", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var vc = segue.destination as! FifthViewController
        vc.heletext = "\(self.scheurtext) \(self.locatietext)"
    }
}
