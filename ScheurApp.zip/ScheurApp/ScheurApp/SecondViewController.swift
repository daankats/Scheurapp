//
//  SecondViewController.swift
//  ScheurApp
//
//  Created by daan kats on 7/14/20.
//  Copyright © 2020 ViaDev. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    @IBOutlet weak var scheurtext: UILabel!
    
    var aantalScheuren = ""
    var soortscheur = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        scheurtext.text = aantalScheuren

    }
    
    @IBAction func soort1button(_ sender: Any) {
        self.soortscheur = "rechte,"
        performSegue(withIdentifier: "soort", sender: self)
    }
    @IBAction func soort2button(_ sender: Any) {
        self.soortscheur = "vrijwel rechte,"
        performSegue(withIdentifier: "soort", sender: self)
    }
    @IBAction func soort3button(_ sender: Any) {
        self.soortscheur = "grillige,"
        performSegue(withIdentifier: "soort", sender: self)
    }
    @IBAction func soort4button(_ sender: Any) {
        self.soortscheur = "getrapte,"
        performSegue(withIdentifier: "soort", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var vc = segue.destination as! ThirdViewController
        vc.scheurtext = "\(self.aantalScheuren) \(self.soortscheur)"
    }

    
}

