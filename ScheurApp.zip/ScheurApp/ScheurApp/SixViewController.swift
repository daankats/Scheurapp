//
//  SixViewController.swift
//  ScheurApp
//
//  Created by daan kats on 7/15/20.
//  Copyright © 2020 ViaDev. All rights reserved.
//

import UIKit

class SixViewController: UIViewController {
    @IBOutlet weak var scheurtext: UILabel!
    
    var heletext = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

       scheurtext.text = heletext
    }
    @IBAction func copytoclipboardbuton(_ sender: Any) {
        UIPasteboard.general.string =  heletext
    }
    @IBAction func Backbutton(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        self.present(nextViewController, animated:true, completion:nil)
  
    }
    

}
