//
//  ThirdViewController.swift
//  ScheurApp
//
//  Created by daan kats on 7/14/20.
//  Copyright © 2020 ViaDev. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {
    @IBOutlet weak var soorttext: UILabel!
    
    var scheurtext = ""
    var richting = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        soorttext.text = scheurtext
      
    }
    
    @IBAction func horizonbutton(_ sender: Any) {
        self.richting = "horizontale"
        performSegue(withIdentifier: "richting", sender: self)
    }
    @IBAction func verticaalbutton(_ sender: Any) {
        self.richting = "verticale"
        performSegue(withIdentifier: "richting", sender: self)
    }
    @IBAction func diagonaalbutton(_ sender: Any) {
        self.richting = "diagonale"
        performSegue(withIdentifier: "richting", sender: self)
    }
    @IBAction func horizonendiabutton(_ sender: Any) {
        self.richting = "horizontale en diagonale"
        performSegue(withIdentifier: "richting", sender: self)
    }
    @IBAction func horizonenvertbutton(_ sender: Any) {
        self.richting = "horizontale en verticale"
        performSegue(withIdentifier: "richting", sender: self)
    }
    @IBAction func vertendiabutton(_ sender: Any) {
        self.richting = "verticale en diagonale"
        performSegue(withIdentifier: "richting", sender: self)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var vc = segue.destination as! FourthViewController
        vc.scheurtext = "\(self.scheurtext) \(self.richting) scheur(en)"
    }
}
