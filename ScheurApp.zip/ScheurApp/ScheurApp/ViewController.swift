//
//  ViewController.swift
//  ScheurApp
//
//  Created by daan kats on 7/14/20.
//  Copyright © 2020 ViaDev. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var Aantalscheuren = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func scheur1button(_ sender: Any) {
        self.Aantalscheuren = "Er is een"
        performSegue(withIdentifier: "scheur", sender: self)
    }
    @IBAction func scheur2button(_ sender: Any) {
        self.Aantalscheuren = "Er zijn twee"
        performSegue(withIdentifier: "scheur", sender: self)
    }
    @IBAction func scheur3button(_ sender: Any) {
        self.Aantalscheuren = "Er zijn drie"
        performSegue(withIdentifier: "scheur", sender: self)
    }
    @IBAction func scheurmeerbutton(_ sender: Any) {
        self.Aantalscheuren = "Er zijn meerdere"
        performSegue(withIdentifier: "scheur", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var vc = segue.destination as! SecondViewController
        vc.aantalScheuren = self.Aantalscheuren
    }

}

